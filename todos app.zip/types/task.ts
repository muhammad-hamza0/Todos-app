export interface ITask {
    id: string,
    title: string,
}