/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-client)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=F%3A%5CHamza%20Data%5CReact%20Practise%5Ctodos-list%5Capp%5Ccomponents%5CTodoItem.tsx&server=false!":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=F%3A%5CHamza%20Data%5CReact%20Practise%5Ctodos-list%5Capp%5Ccomponents%5CTodoItem.tsx&server=false! ***!
  \*****************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/components/TodoItem.tsx */ \"(app-client)/./app/components/TodoItem.tsx\"))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1jbGllbnQpLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9idWlsZC93ZWJwYWNrL2xvYWRlcnMvbmV4dC1mbGlnaHQtY2xpZW50LWVudHJ5LWxvYWRlci5qcz9tb2R1bGVzPUYlM0ElNUNIYW16YSUyMERhdGElNUNSZWFjdCUyMFByYWN0aXNlJTVDdG9kb3MtbGlzdCU1Q2FwcCU1Q2NvbXBvbmVudHMlNUNUb2RvSXRlbS50c3gmc2VydmVyPWZhbHNlISIsIm1hcHBpbmdzIjoiQUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvP2Y4NjEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCJGOlxcXFxIYW16YSBEYXRhXFxcXFJlYWN0IFByYWN0aXNlXFxcXHRvZG9zLWxpc3RcXFxcYXBwXFxcXGNvbXBvbmVudHNcXFxcVG9kb0l0ZW0udHN4XCIpIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-client)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=F%3A%5CHamza%20Data%5CReact%20Practise%5Ctodos-list%5Capp%5Ccomponents%5CTodoItem.tsx&server=false!\n"));

/***/ })

});